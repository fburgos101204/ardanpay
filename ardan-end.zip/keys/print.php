<!DOCTYPE html>
<html>
<head>
	<title>PRINT TICKET</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
  <a href="com.fidelier.printfromweb://$bighw$KLKLKLKLKLKLKLKLKLKLKLK$intro$$cut$$intro$$intro$">PRINT k NOW</a>
</body>
</html>