function show_amrtr()
{
	$("#pagos_realizados").hide();
	$("#btn_amortzacion").hide();
	$("#amortazion").show();
	$("#btn_pagos_realizados").show();
}
function show_pgdrt()
{
	$("#pagos_realizados").show();
	$("#btn_amortzacion").show();
	$("#amortazion").hide();
	$("#btn_pagos_realizados").hide();
}