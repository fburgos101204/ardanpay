<!DOCTYPE html>
<html>
<head>
	<title>PRINT TICKET</title>
</head>
<body>
  <a href="com.fidelier.printfromweb://$bighw$KLKLKLKLKLKLKLKLKLKLKLK$intro$$cut$$intro$$intro$">PRINT NOW</a>
</body>
</html>