<?php 
  include_once("header/header.php");
  include_once("header/menu.php");
?>
<div id="content-wrapper">
<div class="container-fluid">

<ol class="breadcrumb">
<li class="breadcrumb-item">
  <a href=""><?php echo $empresa; ?></a>
</li>
<li class="breadcrumb-item active">ERROR</li>
</ol>
	
</div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<?php
  include_once("header/footer.php"); 
?>