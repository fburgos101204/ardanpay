<?php

  header("location: ../");

	

?>