<?php
/*Datos de conexion a la base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'coordina_fer');//Usuario de tu base de datos
define('DB_PASS', 'Fer10120421');//Contraseña de la base de datos
define('DB_NAME', 'coordina_car');//Nombre de la base de datos
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'brosario');//Usuario de tu base de datos
define('DB_PASS', 'Cambios1395');//Contraseña de la base de datos
define('DB_NAME', 'ardanpay');//Nombre de la base de datos

/*Datos de la empresa*/
define('NOMBRE_EMPRESA', 'SEROTIUS');
define('DIRECCION_EMPRESA', 'Santo Domingo este, Republica Dominicana, RD');
define('TELEFONO_EMPRESA', '+(829) 861-8381');
define('EMAIL_EMPRESA', 'fernandohbd10@gmail.com');
define('TAX', '18');
?>